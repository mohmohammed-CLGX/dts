﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;

public partial class Transactions : System.Web.UI.Page
{
    string strstatecounty;
    string strfiletype;
         string strcommenttype;

    protected void Page_Load(object sender, EventArgs e)
    {
        GridView6.DataBind();
        GridViewResult.DataBind();
        ddlFipssch.Attributes.Add("onchange", "return fipsselchange();");
        ddlcountysch1.Attributes.Add("onchange", "return countyselchange();");
        chkstatesch.Attributes.Add("onclick", "return chkstate();");
        chkcountysch1.Attributes.Add("onclick", "return chkcounty();");
        chkFipssch.Attributes.Add("onclick", "return chkfips();");


        ddlstatesch.Attributes.Add("onchange", "stateselchange();");
        chkIssueTypesch.Attributes.Add("onclick", "Togglecheck('" + chkIssueTypesch.ClientID + "','" + ddlIssuetypesch.ClientID + "','yes');");

        chkFilesch.Attributes.Add("onclick", "Togglecheck('" + chkFilesch.ClientID + "','" + ddlFileTypesch.ClientID + "','yes');");


        chkProcessingsch.Attributes.Add("onclick", "Togglecheck('" + chkProcessingsch.ClientID + "','" + ddlProcessingsch.ClientID + "','yes');");


        chkEditionsch.Attributes.Add("onclick", "Togglecheck('" + chkEditionsch.ClientID + "','" + txtEditionsch.ClientID + "','no');");



        chkRelatedICPsch.Attributes.Add("onclick", "Togglecheck('" + chkRelatedICPsch.ClientID + "','" + txtRelatedICPsch.ClientID + "','no');");


        chkSubmittersch.Attributes.Add("onclick", "Togglecheck('" + chkSubmittersch.ClientID + "','" + txtSubmittersch.ClientID + "','no');");


        chkIssuedetailsch.Attributes.Add("onclick", "Togglecheck('" + chkIssuedetailsch.ClientID + "','" + txtchkIssuedetailsch.ClientID + "','no');");


        chkResolutionsch.Attributes.Add("onclick", "Togglecheck('" + chkResolutionsch.ClientID + "','" + txtResolutionsch.ClientID + "','no');");
     
    }
    protected void btnsave_Submit(object sender, EventArgs e)
    {
        Response.Write("testing submit");
    }
    protected void btnsave_Click(object sender, EventArgs e)
    {
        Response.Write("testing save");
    }
    protected void GridView2_RowCreated(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            e.Row.Attributes.Add("onMouseOver", "this.style.background='#eeff00'");
            e.Row.Attributes.Add("onMouseOut", "this.style.background='#ffffff'");
        }

    }
    protected void GridView2_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        GridView _gridView = (GridView)sender;

        // Get the selected index and the command name
        int _selectedIndex = int.Parse(e.CommandArgument.ToString());
        string _commandName = e.CommandName;

        switch (_commandName)
        {
            case ("SingleClick"):
                _gridView.SelectedIndex = _selectedIndex;
                // this.Message.Text += "Single clicked GridView row at index " + _selectedIndex.ToString() + "<br />";
                break;
            case ("DoubleClick"):
                // this.Message.Text += "Double clicked GridView row at index " + _selectedIndex.ToString() + "<br />";
                Response.Redirect("~/QA-QCSearch.aspx");
                break;
        }

    }
    protected void GridView2_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            // Get the LinkButton control in the first cell
          //  LinkButton _singleClickButton = (LinkButton)e.Row.Cells[0].Controls[0];
            // Get the javascript which is assigned to this LinkButton
           // string _jsSingle = ClientScript.GetPostBackClientHyperlink(_singleClickButton, "");
            // To prevent the first click from posting back immediately 
            // (therefore giving the user a chance to double click) pause the 
            // postback for 300 milliseconds by using setTimeout
          //  _jsSingle = _jsSingle.Insert(11, "setTimeout(\"");
            //_jsSingle += "\", 300)";
            // Add this javascript to the onclick Attribute of the row
          //  e.Row.Attributes["onclick"] = _jsSingle;

            // Get the LinkButton control in the second cell
            //LinkButton _doubleClickButton = (LinkButton)e.Row.Cells[1].Controls[0];
            // Get the javascript which is assigned to this LinkButton
           // string _jsDouble = ClientScript.GetPostBackClientHyperlink(_doubleClickButton, "");
            // Add this javascript to the ondblclick Attribute of the row
            //e.Row.Attributes["ondblclick"] = _jsDouble;
        }
    }
    protected void CheckBox1_CheckedChanged(object sender, EventArgs e)
    {

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        string strconn = System.Configuration.ConfigurationManager.ConnectionStrings["kbConnectionString"].ToString();
    
        
        string FIPSCounty=ddlstate_countynew.SelectedValue.ToString();
        string IDProcessingType=ddlProcessingtypenew.SelectedValue.ToString();
        string IDFileType=ddlFileTypenew.SelectedValue.ToString();
        string IDIssueType=ddlIssueTypenew.SelectedValue.ToString();
        string Edition=txtEditionnew.Text;
        string strVersion=txtVersionnew.Text;
        string Title=txtTitlenew.Text;
        string IssueDetails=txtIssueDetailsnew.Text;
        string Resolution=txtResolutionnew.Text;
        string Submitter=txtSubmitternew.Text;
        string Relatedlink=txtRelatedLinksnew.Text;
        string ICP=txtICPnew.Text;
        string IssueCreatedDate=DateTime.Now.ToString("yyyy/MM/dd");



        string command = "insert into [Issuetbl](FIPSCounty,IDProcessingType,IDFileType,IDIssueType,Edition,Version,Title,IssueDetails,Resolution," +
                           "Submitter,Relatedlink,ICP,IssueCreatedDate) "+
                             " Values('" + FIPSCounty + "'," + IDProcessingType + "," + IDFileType + "," + IDIssueType + "," + Edition+","+
                         strVersion + ",'" + Title + "','"+IssueDetails+ "','"+Resolution + "','"+Submitter+ "','"+Relatedlink+"',"+ICP+",'"+
                        IssueCreatedDate+"')";
        
        
        
        
        
        
        
      
        try
        {
            SqlConnection conn = new SqlConnection(strconn);
           SqlCommand cmd = new SqlCommand(command, conn);
            conn.Open();
            cmd.ExecuteNonQuery();
            conn.Close();
            ddlstate_countynew.SelectedIndex = 0;

            ddlfpisnew.SelectedIndex = 0;
            ddlProcessingtypenew.SelectedIndex = 0;
            ddlFileTypenew.SelectedIndex = 0;
            ddlIssueTypenew.SelectedIndex = 0;
            txtEditionnew.Text = "";
            txtVersionnew.Text = "";
            txtTitlenew.Text = "";
            txtIssueDetailsnew.Text = "";
            txtResolutionnew.Text = "";
            txtICPnew.Text = "";
            txtSubmitternew.Text = "";
            txtRelatedLinksnew.Text = "";
    
           
            GridView5.DataBind();
            GridView6.DataBind();
            GridViewResult.DataBind();


        }
        catch (Exception ex)
        {
        }
    }





}
